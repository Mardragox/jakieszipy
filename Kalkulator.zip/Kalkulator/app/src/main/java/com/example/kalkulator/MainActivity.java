package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button buttonSilnia;
    private Button buttonSuma;
    private Button buttonSumaAB;
    private Button buttonPotega;
    private Button buttonDzielniki;
    private Button buttonSito;
    private EditText editTextLiczba1;
    private EditText editTextLiczba2;

    private TextView textViewWynik;

    private ListView listView;
    private ArrayAdapter<Integer> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonSuma = findViewById(R.id.buttonSuma);
        buttonSilnia = findViewById(R.id.buttonSilnia);
        buttonPotega = findViewById(R.id.buttonPAB);
        buttonSumaAB = findViewById(R.id.buttonSAB);
        editTextLiczba1 = findViewById(R.id.liczba1Input);
        editTextLiczba2 = findViewById(R.id.liczba2Input);
        textViewWynik = findViewById(R.id.textView);
        buttonDzielniki = findViewById(R.id.button);
        buttonSito = findViewById(R.id.buttonLP);
        listView = findViewById(R.id.listView);
        buttonDzielniki.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int liczba = Integer.parseInt(editTextLiczba1.getText().toString());
                        ArrayList<Integer> pierwszeLiczby = dzielnikiLiczby(liczba);
                        arrayAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1,pierwszeLiczby);
                        listView.setAdapter(arrayAdapter);
                    }
                }
        );

        buttonSito.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int liczba = Integer.parseInt(editTextLiczba1.getText().toString());
                        ArrayList<Integer> dzielniki = sitoErastotenesa(liczba);
                        arrayAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1,dzielniki);
                        listView.setAdapter(arrayAdapter);
                    }
                }
        );

        buttonSuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(editTextLiczba1.getText().toString());
                int b = Integer.parseInt(editTextLiczba2.getText().toString());
                int suma = a + b;
                textViewWynik.setText("Wynik Dodawania to: " + suma);
            }
        });
        buttonSumaAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(editTextLiczba1.getText().toString());
                int b = Integer.parseInt(editTextLiczba2.getText().toString());
                int suma = 0;
                if (a>b){
                    a = a+b;
                    b = a - b;
                    a = a - b;
                }
                for (int i = a; i <= b ; i++) {
                    suma = suma+i;
                }

                textViewWynik.setText("Wynik Dodawania to: " + suma);
            }
        });
        buttonSilnia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(editTextLiczba1.getText().toString());
                int silnia = 1;
                for (int i = 1; i <= a; i++) {
                    silnia = silnia * i;

                }
                textViewWynik.setText("Silnia liczby "+a+" to: " + silnia);
            }
        });
        buttonPotega.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(editTextLiczba1.getText().toString());
                int b = Integer.parseInt(editTextLiczba2.getText().toString());
                int potega = 1;
                for (int i = 1; i <= b; i++) {
                    potega = potega * a;

                }
                textViewWynik.setText("Potęga liczby "+a+" do liczby "+b+" to: " + potega);
            }
        });




    }


    private ArrayList<Integer> sitoErastotenesa(int liczba){
        ArrayList<Integer> pierwszeLiczby = new ArrayList<>();
        boolean pierwsza[] = new boolean[liczba + 1];
        for (int i = 1; i < Math.sqrt(liczba) ; i++) {
            if (pierwsza[i]){
                for (int j = (i*i); j < liczba ; j++) {
                    pierwsza[j] = false;
                }
                pierwszeLiczby.add(liczba);
            }
        }

      return pierwszeLiczby;
    }



    private ArrayList<Integer> dzielnikiLiczby(int liczba){
        ArrayList<Integer> dzielniki = new ArrayList<>();
        for (int i = 1; i <= Math.sqrt(liczba) ;i++){
            if (liczba%i == 0){
                dzielniki.add(i);
                if (i!=liczba/i) {
                    dzielniki.add(liczba / i);
                }
            }

        }

        return dzielniki;
    }



}