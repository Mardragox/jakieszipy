package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button buttonSilnia;
    private Button buttonSuma;
    private Button buttonSumaAB;
    private Button buttonPotega;

    private EditText editTextLiczba1;
    private EditText editTextLiczba2;

    private TextView textViewWynik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonSuma = findViewById(R.id.buttonSuma);
        buttonSilnia = findViewById(R.id.buttonSilnia);
        buttonPotega = findViewById(R.id.buttonPAB);
        buttonSumaAB = findViewById(R.id.buttonSAB);
        editTextLiczba1 = findViewById(R.id.liczba1Input);
        editTextLiczba2 = findViewById(R.id.liczba2Input);
        textViewWynik = findViewById(R.id.textView);

        buttonSuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(editTextLiczba1.getText().toString());
                int b = Integer.parseInt(editTextLiczba2.getText().toString());
                int suma = a + b;
                textViewWynik.setText("Wynik Dodawania to: " + suma);
            }
        });
        buttonSumaAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(editTextLiczba1.getText().toString());
                int b = Integer.parseInt(editTextLiczba2.getText().toString());
                int suma = 0;
                if (a>b){
                    a = a+b;
                    b = a - b;
                    a = a - b;
                }
                for (int i = a; i <= b ; i++) {
                    suma = suma+i;
                }

                textViewWynik.setText("Wynik Dodawania to: " + suma);
            }
        });
        buttonSilnia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(editTextLiczba1.getText().toString());
                int silnia = 1;
                for (int i = 1; i <= a; i++) {
                    silnia = silnia * i;

                }
                textViewWynik.setText("Silnia liczby "+a+" to: " + silnia);
            }
        });
        buttonPotega.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(editTextLiczba1.getText().toString());
                int b = Integer.parseInt(editTextLiczba2.getText().toString());
                int potega = 1;
                for (int i = 1; i <= b; i++) {
                    potega = potega * a;

                }
                textViewWynik.setText("Potęga liczby "+a+" do liczby "+b+" to: " + potega);
            }
        });

    }



}