import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class JanTesty {


    @Test
    void NaPierwszaDuzaLitereJasGdyjas() {
        Assertions.assertEquals("Jaś", JanMetody.zMalychLiterNaDuze("jaś"));
    }

    @Test
    void NaPierwszaDuzaLitereJasGdySpacjePrzedIPo(){
        Assertions.assertEquals("Jaś", JanMetody.zMalychLiterNaDuze("  jaś  "));
    }

    @Test
    void NaPierwszaDuzaLitereJasGdyWszystkoZDuzej(){
        Assertions.assertEquals("Jaś",JanMetody.zMalychLiterNaDuze("JAŚ"));
    }

    @Test
    void NaPierwszaDuzaLitereJasGdyJeszczeJakiesLiczby(){
        Assertions.assertEquals("Jaś",JanMetody.zMalychLiterNaDuze("jaś23"));
    }
}
