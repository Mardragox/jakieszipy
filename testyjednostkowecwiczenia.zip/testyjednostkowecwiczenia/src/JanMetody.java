public class JanMetody {


    public static String zMalychLiterNaDuze (String tekst){

        String zamienione = "";
        String litery = "QWERTYUIOPASDFGHJKLZXCVBNMĄŻŹŚĘĆŃÓŁ";
        tekst = tekst.trim();
        tekst = tekst.toUpperCase();
        zamienione += tekst.charAt(0);
        String slowoDoZamianySameLitery = "";
        for(int i = 0; i <tekst.length(); i++){
            if (litery.contains((tekst.charAt(i)+""))){
                slowoDoZamianySameLitery += tekst.charAt(i);
            }
        }
        tekst = slowoDoZamianySameLitery;


        tekst = tekst.toLowerCase();
        zamienione += tekst.substring(1);




        return zamienione;
    }
/**
    public static String zDuzychNaMale (String tekst){

        String zamienione = "";
        tekst = tekst.trim();
        tekst = tekst.toLowerCase();
        zamienione += tekst.charAt(0);
        tekst = tekst.toUpperCase();
        zamienione += tekst.substring(1);


        return zamienione;
    }

*/
}
