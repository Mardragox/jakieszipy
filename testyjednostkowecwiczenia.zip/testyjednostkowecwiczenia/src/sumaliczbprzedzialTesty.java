import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class sumaliczbprzedzialTesty {

    @Test
    void przedzialNormalny(){
        Assertions.assertEquals(14,sumaliczbprzedzialMetody.sumaPrzedzialu(2,5));
    }


}
