public class NWDMetody {


    public static int NWDTakieCoSieDzielaZReszta(int liczbaJeden, int liczbaDwa) {


        int a = liczbaJeden;
        int b = liczbaDwa;
        int c;
/**
        if (a == 0) {

            return b;
        } else if (b == 0) {

            return a;
        }
        else {
            do {
                c = a % b;
                a = b;
                b = c;
            } while (b != 0);

            return a;
        }
 */


        if (a == 0) {

            return b;
        } else if (b == 0) {

            return a;
        }



        do {
            if (a>b){
                a = a - b;
            }else{
                b = b - a;
            }
        } while (a != b);

            return a;
    }



}
