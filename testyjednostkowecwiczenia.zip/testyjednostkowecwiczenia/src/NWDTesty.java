import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class NWDTesty {

    @Test
    void NWDTakieCoSieDzielaZReszta(){
        Assertions.assertEquals(1,NWDMetody.NWDTakieCoSieDzielaZReszta(7,20));
    }

    @Test
    void NWMGdyJednaLiczbaToZero(){
        Assertions.assertEquals(7,NWDMetody.NWDTakieCoSieDzielaZReszta(7,0));
    }

    @Test
    void NWMGdyJednaLiczbaToZeroAleNaOdwrot(){
        Assertions.assertEquals(5,NWDMetody.NWDTakieCoSieDzielaZReszta(0,5));
    }

    @Test
    void NWMGdySieDzieliLadnie(){
        Assertions.assertEquals(5,NWDMetody.NWDTakieCoSieDzielaZReszta(25,40));
    }

}
