public class sumaliczbprzedzialMetody {

    public static int sumaPrzedzialu(int poczatek, int koniec){
        int a;
        int b;
        int liczba;
        if (koniec > poczatek){
            a = poczatek;
            b = koniec;
        }else {
            a = koniec;
            b = poczatek;
        }
        for (int i = a; i > b; i++){
            liczba = a;
            a = a + liczba;
            liczba++;

        }

        return a;
    }

}
