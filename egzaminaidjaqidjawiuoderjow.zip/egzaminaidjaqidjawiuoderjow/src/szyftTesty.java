import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class szyftTesty {

    @Test
    public void zaszyfrowanieTest(){
        Assertions.assertEquals("def",Main.szyfrowanie("abc"));
    }


}
