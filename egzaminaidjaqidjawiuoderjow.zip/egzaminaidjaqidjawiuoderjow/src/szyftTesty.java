import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class szyftTesty {

    @Test
    public void zaszyfrowanieTest(){
        Assertions.assertEquals("def",Main.szyfrowanie("xyz", -3));
    }


    @Test
    public void zaszyfrowanieTestDluzszeSlowo(){
        Assertions.assertEquals("def",Main.szyfrowanie("abc", 1));
    }

    @Test
    public void zaszyfrowanieTestDluzszeSlowo(){
        Assertions.assertEquals("bfablnj",Main.szyfrowanie("aezakmi", 1));
    }

    @Test
    public void zaszyfrowanieTestDluzszeSlowo(){
        Assertions.assertEquals("bfablnj",Main.szyfrowanie("aezakmi", 1));
    }

}
