public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

    }




    public static String szyfrowanie(String slowo){
        String zaszyfrowane = "";
        String klucz = "abcdefghijklmnopqrstuwxyz";

        for (int i = 0; i<slowo.length();i++){
            slowo.charAt(i) = klucz.charAt(i+3);
        }

        return zaszyfrowane;
    }




}