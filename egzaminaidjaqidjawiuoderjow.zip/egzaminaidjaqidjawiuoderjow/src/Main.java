import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Scanner scanner = new Scanner(System.in);

        System.out.println("Podejno słowo");
        String slowo = scanner.next();
        System.out.println("Podejno klucz");
        int klucz = scanner.nextInt();
        System.out.println("Zaszyfrowano: ");
        System.out.println(szyfrowanie(slowo,klucz));
    }




    public static String szyfrowanie(String slowo, int klucz){
        String alfabetZaszyfrowany;
        String alfabet = "abcdefghijklmnopqrstuvwxyz";
        if(klucz >0) {
            alfabetZaszyfrowany = alfabet.substring(klucz) + alfabet.substring(0, klucz);
        }else{
            klucz = klucz*-1;
            alfabetZaszyfrowany = alfabet.substring(alfabet.length() - klucz)+ alfabet.substring(0, alfabet.length()-klucz);
        }


            String zaszyfrowane = "";
        for (int i = 0; i<slowo.length();i++){
            char aktualnaLitera = slowo.charAt(i);
            if (aktualnaLitera == ' '){
                zaszyfrowane = zaszyfrowane + ' ';
                continue;
            }
            int indexLitery = alfabet.indexOf(aktualnaLitera);
            char literawprzesunietym = alfabetZaszyfrowany.charAt(indexLitery);
            zaszyfrowane += literawprzesunietym;

        }

        return zaszyfrowane;
    }




}