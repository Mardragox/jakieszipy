public class potegowanieMetody {

    public static double potegowanie (int podstawa, int wykladnik){

        double p=1;
        boolean mniejszy = false;
        if (wykladnik < 0){
            mniejszy = true;
            wykladnik = wykladnik * -1;
        }
        for (int i = 0;i < wykladnik; i++){
            p = podstawa * p;
        }
        if (mniejszy){
            return 1/p;
        }
        return p;
    }


}
