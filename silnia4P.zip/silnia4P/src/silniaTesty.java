import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class silniaTesty {

    @Test
    void silniaTestArgument0() {
        Assertions.assertEquals(1, silnia.silnia(0));}

    @Test
    void silniaTestArgument1() {
        Assertions.assertEquals(1, silnia.silnia(1));}
    @Test
    void silniaTestArgumentMaly() {
        Assertions.assertEquals(120, silnia.silnia(5));}
    @Test
    void silniaTestArgumentDuzy() {
        Assertions.assertEquals(479001600, silnia.silnia(12));}
}
