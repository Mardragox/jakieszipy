public class silnia {

    public static long silnia (int a) {
        long wynikSilnia = 1;
        for (int i = 1; i <= a; i++) {
            wynikSilnia = wynikSilnia * i;
        }
        return wynikSilnia;
        }

    }
