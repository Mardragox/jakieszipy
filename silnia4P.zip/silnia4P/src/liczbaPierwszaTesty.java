import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class liczbaPierwszaTesty {

    @Test
    void liczbaPierwszaTestArgument1(){
        Assertions.assertEquals(false,liczbaPierwszaMetody.czyLiczbaPierwsza(1));
    }

    @Test
    void liczbaPierwszaTestArgument2(){
        Assertions.assertEquals(true,liczbaPierwszaMetody.czyLiczbaPierwsza(2));
    }

    @Test
    void liczbaPierwszaTestArgumentWiekszyAleNieNajwiekszy(){
        Assertions.assertEquals(false,liczbaPierwszaMetody.czyLiczbaPierwsza(75));
    }

    @Test
    void liczbaPierwszaTestArgumentTakiSredni(){
        Assertions.assertEquals(true,liczbaPierwszaMetody.czyLiczbaPierwsza(17));
    }

    @Test
    void liczbaPierwszaTestArgumentBardzoDuzaLiczba(){
        Assertions.assertEquals(true,liczbaPierwszaMetody.czyLiczbaPierwsza(100003));
    }

    @Test
    void liczbaPierwszaTestArgumentZKwadratu(){
        Assertions.assertEquals(false,liczbaPierwszaMetody.czyLiczbaPierwsza(25));
    }

}
