import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class potegowanieTesty {

    @Test
    void potegowanieKiedyLiczba0(){
        Assertions.assertEquals(1,potegowanieMetody.potegowanie(2,0));
    }

    @Test
    void potegowanieKiedyLiczba1(){
        Assertions.assertEquals(2,potegowanieMetody.potegowanie(2,1));
    }

    @Test
    void potegowanieKiedyLiczba10(){
        Assertions.assertEquals(1024,potegowanieMetody.potegowanie(2,10));
    }

    @Test
    void potegowanieKiedyLiczbaUjemna(){
        Assertions.assertEquals(0.5, potegowanieMetody.potegowanie(2,-1));
    }



}
