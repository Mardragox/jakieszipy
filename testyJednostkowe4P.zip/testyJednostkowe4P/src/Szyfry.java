public class Szyfry {
    public static String szyfruj_cezarem(String slowo, int klucz){
        String zaszyfrowane = "";

        klucz = klucz%26;
        boolean czyDuze = false;
        if(slowo.equals(slowo.toUpperCase())){
            slowo = slowo.toLowerCase();
            czyDuze = true;
        }
        String alfabet = "abcdefghijklmnoprstuvwxyz";
        String alfabet_przesuniety;

        if(klucz<0){
            klucz = klucz * -1;
            alfabet_przesuniety = alfabet.substring(alfabet.length() - klucz) + alfabet.substring(0,klucz);
        }
        else{
            alfabet_przesuniety = alfabet.substring(klucz) + alfabet.substring(0,klucz);
        }



        for(int i = 0; i < slowo.length() ;i++){
            if(slowo.charAt(i) == ' '){
                zaszyfrowane = zaszyfrowane + " ";
                continue;
            }
            int index = alfabet.indexOf(slowo.charAt(i));
            zaszyfrowane = zaszyfrowane + alfabet_przesuniety.charAt(index);
        }

        if(czyDuze){
            return zaszyfrowane.toUpperCase();

        }
        return zaszyfrowane;
    }
    public static String szyfrujCezaremAscii (String slowo, int klucz){
        String zaszyfrowane = "";
        klucz = klucz%26;
        boolean czyDuzeAscii = false;

        for (int i = 0; i < slowo.length(); i++){
            int kod = (int)slowo.charAt(i)+klucz;
            if (kod > (int)'z'){
                kod = kod -26;
            }
            if (kod < (int)'a'){
                kod = kod +26;
            }
            zaszyfrowane = zaszyfrowane + (char)kod;
        }

        return zaszyfrowane;
    }

}
