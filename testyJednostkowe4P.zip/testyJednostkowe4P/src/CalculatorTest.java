import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    @Test
    void testSumaJezeliWynikCalkowity() {
        Assertions.assertEquals(5,Calculator.suma(2,3));
    }

    @Test
    void testSumaJezeliWynikRzeczywisty() {
        Assertions.assertEquals(5.4,Calculator.suma(2.4,3));
    }

    @Test
    void testPodzielJezeliWynikCalkowity(){
        Assertions.assertEquals(3,Calculator.podziel(12,4));
    }

    @Test
    void testPodzielJezeliRzeczywistyParametryCalkowite(){
        Assertions.assertEquals(2.4,Calculator.podziel(12,5));
    }

    @Test
    void testPodzielJezeliRzeczywistyParametryRzeczywiste(){
        Assertions.assertEquals(2.5,Calculator.podziel(12.5,5));
    }

    @Test
    void testCzyPierwszaJezeli1(){
        Assertions.assertFalse(Calculator.);
    }
}