public class Calculator {
    public static int suma (int a, int b){
        return a+b;
    }

    public static double suma (double a, double b){
        return a+b;
    }

    public static double podziel (double a, double b){
        return a/b;
    }

    public static double podziel (int a, int b){
        return (double)a/(double)b;
    }

}
