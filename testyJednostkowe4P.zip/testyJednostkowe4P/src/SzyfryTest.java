import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SzyfryTest {


    //technika TDD = test drive development - pisanie testów w trakcie pisania kodu,
    // analizujemy problem, rozpisujemy możliwe sytuacje,
    // podczas programowania run testów


    @Test
    void szyfruj_cezarem_test() {
        Assertions.assertEquals("def",Szyfry.szyfruj_cezarem("abc",3));
    }

    @Test
    void szyfruj_cezarem_test_klucz_ujemny() {
        Assertions.assertEquals("abc",Szyfry.szyfruj_cezarem("def",-3));
    }

    @Test
    void szyfruj_cezarem_test_z_spacją() {
        Assertions.assertEquals("d ef",Szyfry.szyfruj_cezarem("a bc",3));
    }

    @Test
    void szyfruj_cezarem_test_z_spacją_i_ujemnoscia() {                                                         //dodatkowy
        Assertions.assertEquals("x yz",Szyfry.szyfruj_cezarem("a bc",-3));
    }

    @Test
    void szyfruj_cezarem_test_duze_litery_z_ujemnoscia() {
        Assertions.assertEquals("XYZ",Szyfry.szyfruj_cezarem("ABC",-3));
    }

    @Test
    void szyfruj_cezarem_test_duze_litery() {                                                                    //dodatkowy
        Assertions.assertEquals("DEF",Szyfry.szyfruj_cezarem("ABC",3));
    }

    @Test
    void szyfruj_cezarem_test_klucz_ujemny_z_zawijaniem() {
        Assertions.assertEquals("xyz",Szyfry.szyfruj_cezarem("abc",-3));
    }

    @Test
    void szyfruj_cezarem_test_z_zawijaniem() {
        Assertions.assertEquals("abc",Szyfry.szyfruj_cezarem("xyz",3));
    }

    @Test
    void szyfruj_cezarem_test_klucz_wiekszy_niz_alfabet() {
        Assertions.assertEquals("efg",Szyfry.szyfruj_cezarem("abc",30));
    }

    @Test
    void szyfruj_cezarem_test_klucz_wiekszy_od_alfabetu_i_ujemny() {
        Assertions.assertEquals("abc",Szyfry.szyfruj_cezarem("efg",-30));
    }

    @Test
    void szyfruj_cezarem_testAscii() {
        Assertions.assertEquals("def",Szyfry.szyfrujCezaremAscii("abc",3));
    }

    @Test
    void szyfruj_cezarem_test_klucz_ujemnyAscii() {
        Assertions.assertEquals("abc",Szyfry.szyfrujCezaremAscii("def",-3));
    }

    @Test
    void szyfruj_cezarem_test_z_spacjąAscii() {
        Assertions.assertEquals("d ef",Szyfry.szyfrujCezaremAscii("a bc",3));
    }

    @Test
    void szyfruj_cezarem_test_z_spacją_i_ujemnosciaAscii() {                                                         //dodatkowy
        Assertions.assertEquals("x yz",Szyfry.szyfrujCezaremAscii("a bc",-3));
    }

    @Test
    void szyfruj_cezarem_test_duze_litery_z_ujemnosciaAscii() {
        Assertions.assertEquals("XYZ",Szyfry.szyfrujCezaremAscii("ABC",-3));
    }

    @Test
    void szyfruj_cezarem_test_duze_literyAscii() {                                                                    //dodatkowy
        Assertions.assertEquals("DEF",Szyfry.szyfrujCezaremAscii("ABC",3));
    }

    @Test
    void szyfruj_cezarem_test_klucz_ujemny_z_zawijaniemAscii() {
        Assertions.assertEquals("xyz",Szyfry.szyfrujCezaremAscii("abc",-3));
    }

    @Test
    void szyfruj_cezarem_test_z_zawijaniemAscii() {
        Assertions.assertEquals("abc",Szyfry.szyfrujCezaremAscii("xyz",3));
    }

    @Test
    void szyfruj_cezarem_test_klucz_wiekszy_niz_alfabetAscii() {
        Assertions.assertEquals("efg",Szyfry.szyfrujCezaremAscii("abc",30));
    }

    @Test
    void szyfruj_cezarem_test_klucz_wiekszy_od_alfabetu_i_ujemnyAscii() {
        Assertions.assertEquals("abc",Szyfry.szyfrujCezaremAscii("efg",-30));
    }

}