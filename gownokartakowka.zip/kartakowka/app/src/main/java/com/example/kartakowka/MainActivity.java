package com.example.kartakowka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private EditText textWpisany;
    private Button sysChange;
    private Button numChange;
    private Spinner sysSelect;
    private TextView outputText;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<String> systems = new ArrayList<String>(Arrays.asList(getResources().getStringArray(R.array.systemy)));
        textWpisany = findViewById(R.id.editTextWpiszLiczbe);
        sysChange = findViewById(R.id.buttonSys);
        numChange = findViewById(R.id.buttonNum);
        outputText = findViewById(R.id.textViewWynik);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_item, systems);

        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(arrayAdapter);




    sysChange.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

        String liczba = textWpisany.getText().toString();
        int system = spinner.getSelectedItemPosition()+2;
        int wynik = dziesietnyChange(liczba, system);
        outputText.setText("Wynik: "+wynik);




        }
    });


    }

    private int dziesietnyChange(String liczba,int system){

        int wynik = 0;
        int potega = 1;
        int cyfra;
        for (int i = 0; i <= liczba.length()-1; i++) {
            if ((int)liczba.charAt(i)<=(int)'9') {
                cyfra = (int) liczba.charAt(i) - (int) '0';
            }else{
                cyfra = (int) liczba.charAt(i) - (int) 'A'+10;
            }
            wynik = wynik + cyfra*potega;
            potega = potega*system;

        }
        return wynik;
    }

}