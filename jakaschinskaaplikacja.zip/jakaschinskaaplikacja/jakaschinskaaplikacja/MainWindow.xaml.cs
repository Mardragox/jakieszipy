﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace jakaschinskaaplikacja
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    { 
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (sender is Button btn && int.TryParse(btn.Tag.ToString(), out int liczba))
            {
               
                generuj(liczba);

            }

            


        }


        private void generuj(int x)
        {
            String haslo = "";
            String imieLitera = "";
            int liczba = 0;
            Int32.TryParse(wiekBox.Text, out liczba);
            imieLitera = imieBox.Text.Trim().ToUpper();
            if (imieBox.Text == "" || nazwiskoBox.Text == "" || wiekBox.Text == "")
            {
                loginBlock.Content = "Nie podano danych";
            }
            else
            {
                haslo += imieLitera.ElementAt(0) + nazwiskoBox.Text.ToLower() + (liczba%x).ToString();
                
                loginBlock.Content = "Twój login to: " + haslo;

            }
        }
    }
}